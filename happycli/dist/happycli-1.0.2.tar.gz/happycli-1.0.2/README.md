HappyCLI 😊



Install:

pip install happycli



Run:

happy



